import React from "react";
 import spo from "../assets/sponsors.svg";
;
const Sponsors = () => {
  return (   
    
    <section id="sponsors" className="sponsors-section">
      <h2>SPONS<span className="blue-text">OR</span>S</h2>
      <img src={spo} alt="404" /> 
    </section>
  ); 
  };
  export default Sponsors